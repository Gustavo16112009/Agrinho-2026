// 1. Banco de dados com as 20 perguntas oficiais sobre o tema do Agrinho 2026
const perguntas = [
    {
        pergunta: "Qual técnica evita a erosão do solo mantendo a palha da colheita anterior?",
        opcoes: ["Plantio Direto", "Queimada Controlada", "Arado Profundo", "Compactação do solo"],
        correta: 0
    },
    {
        pergunta: "Qual método de irrigação economiza mais água jogando gotas direto na raiz?",
        opcoes: ["Aspersão", "Inundação", "Gotejamento", "Pivô Central"],
        correta: 2
    },
    {
        pergunta: "Como os drones ajudam na sustentabilidade do agro?",
        opcoes: ["Substituindo os tratores totalmente", "Mapeando pragas para aplicar defensivos apenas onde é necessário", "Espantando pássaros da lavoura", "Fazendo a colheita manual"],
        correta: 1
    },
    {
        pergunta: "O que é a Rotação de Culturas?",
        opcoes: ["Alternar as espécies plantadas na mesma área a cada safra", "Girar as sementes antes do plantio", "Mudar a fazenda de lugar todo ano", "Usar tratores em círculos"],
        correta: 0
    },
    {
        pergunta: "Qual dessas fontes é uma energia limpa muito usada em fazendas sustentáveis?",
        opcoes: ["Carvão mineral", "Energia Solar", "Geradores a Diesel", "Petróleo"],
        correta: 1
    },
    {
        pergunta: "O que são as APPs (Áreas de Preservação Permanente) nas propriedades rurais?",
        opcoes: ["Áreas destinadas apenas ao estoque de grãos", "Áreas protegidas como margens de rios e encostas para evitar desmoronamentos", "Espaços para o confinamento de gado", "Estradas principais da fazenda"],
        correta: 1
    },
    {
        pergunta: "Como o Biogás é produzido em uma fazenda sustentável?",
        opcoes: ["Através da queima de árvores nativas", "A partir da decomposição de resíduos orgânicos e esterco de animais", "Comprando gás natural encanado", "Retirando do solo por perfuração"],
        correta: 1
    },
    {
        pergunta: "O que é the Controle Biológico de pragas?",
        opcoes: ["Usar predadores naturais para combatê-las", "Aumentar a dose de produtos químicos", "Cercar a plantação com telas plásticas", "Inundar a lavoura para afogar os insetos"],
        correta: 0
    },
    {
        pergunta: "Qual a vantagem de integrar a Floresta com a Pecuária (ILPF)?",
        opcoes: ["Deixar o pasto mais seco", "Dar sombra ao gado, melhorar o solo e gerar madeira sustentável", "Dificultar o movimento dos animais", "Eliminar a necessidade de água para o gado"],
        correta: 1
    },
    {
        pergunta: "O que é a Agricultura de Precisão?",
        opcoes: ["Plantar tudo no mesmo dia", "Usar tecnologia e dados para aplicar insumos na quantidade exata e no lugar certo", "Utilizar apenas ferramentas manuais", "Medir o tamanho da fazenda com fita métrica"],
        correta: 1
    },
    {
        pergunta: "Por que as abelhas são importantes para o Agro sustentável?",
        opcoes: ["Porque elas produzem defensivos agrícolas", "Porque fazem a polinização, essencial para a produção de frutos e sementes", "Porque limpam as folhas das plantas", "Elas não têm importância para a lavoura"],
        correta: 1
    },
    {
        pergunta: "O que o produtor deve fazer com as embalagens vazias de defensivos agrícolas?",
        opcoes: ["Queimar no fundo da propriedade", "Jogar no rio mais próximo", "Realizar a tríplice lavagem e devolver nos postos de recebimento autorizados", "Enterrar perto da plantação"],
        correta: 2
    },
    {
        pergunta: "Como a cobertura morta (palhada) ajuda a proteger a água no solo?",
        opcoes: ["Ela impede que a água da chuva chegue à raiz", "Ela diminui a evaporação, mantendo a umidade da terra por mais tempo", "Ela altera a cor do solo para puxar sol", "Ela seca o solo rapidamente para evitar fungos"],
        correta: 1
    },
    {
        pergunta: "Qual o principal objetivo do manejo sustentável de pastagens?",
        opcoes: ["Colocar o máximo de animais no menor espaço possível", "Evitar a degradação do solo e garantir alimento contínuo para o gado", "Deixar o solo exposto ao sol", "Eliminar todas as árvores do pasto"],
        correta: 1
    },
    {
        pergunta: "O que é a adubação verde?",
        opcoes: ["Pintar o solo com corante natural", "Cultivar plantas que nutrem o solo e depois incorporá-las à terra", "Usar apenas adubos químicos artificiais", "Regar as plantas com água colorida"],
        correta: 1
    },
    {
        pergunta: "O que caracteriza a Agricultura Orgânica?",
        opcoes: ["O uso intensivo de transgênicos", "A produção sem o uso de fertilizantes sintéticos e defensivos químicos", "O plantio feito apenas em estufas fechadas", "O uso de sementes artificiais"],
        correta: 1
    },
    {
        pergunta: "Como cisternas ajudam na sustentabilidade rural?",
        opcoes: ["Armazenam água da chuva para ser usada na limpeza e irrigação", "Serve como piscina para os animais", "Para guardar ferramentas pesadas", "Para acumular lixo orgânico"],
        correta: 0
    },
    {
        pergunta: "Qual o benefício do reflorestamento de matas ciliares?",
        opcoes: ["Aumentar a área de plantio", "Proteger os rios contra o assoreamento e preservar a água", "Deixar a fazenda mais bonita visualmente apenas", "Atrair pragas para longe da lavoura"],
        correta: 1
    },
    {
        pergunta: "O que significa o termo 'Pegada de Carbono' no agro?",
        opcoes: ["A marca que os tratores deixam na terra", "A quantidade de gases de efeito estufa emitidos nas atividades da fazenda", "O tamanho do carvão produzido", "A profundidade das raízes das plantas"],
        correta: 1
    },
    {
        pergunta: "O que é o desenvolvimento sustentável no campo?",
        opcoes: ["Produzir alimentos focando apenas no lucro imediato", "Equilibrar a produção econômica, a justiça social e a preservação ambiental", "Parar de produzir para proteger as florestas", "Substituindo todos os funcionários por robôs"],
        correta: 1
    }
];

let indicePerguntaAtual = 0;
let pontuacao = 0;

// Capturando elementos do HTML de forma segura
const telaInicio = document.getElementById('tela-inicio');
const telaJogo = document.getElementById('tela-jogo');
const telaFim = document.getElementById('tela-fim');
const btnComecar = document.getElementById('btn-comecar');
const btnReiniciar = document.getElementById('btn-reiniciar');
const perguntaTitulo = document.getElementById('pergunta-titulo');
const opcoesContainer = document.getElementById('opcoes-container');
const mensagemFeedback = document.getElementById('mensagem-feedback');
const progressoTexto = document.getElementById('progresso-texto');
const barraPreenchimento = document.getElementById('barra-preenchimento');
const pontuacaoFinal = document.getElementById('pontuacao-final');
const mensagemDesempenho = document.getElementById('mensagem-desempenho');

// Iniciar o Desafio
function iniciarJogo() {
    telaInicio.classList.add('escondido');
    telaFim.classList.add('escondido');
    telaJogo.classList.remove('escondido');
    
    indicePerguntaAtual = 0;
    pontuacao = 0;
    
    mostrarPergunta();
}

// Renderizar Pergunta Atual
function mostrarPergunta() {
    mensagemFeedback.textContent = "";
    mensagemFeedback.className = "";
    opcoesContainer.innerHTML = "";
    
    // Atualizar barra de progresso e texto
    progressoTexto.textContent = `Pergunta ${indicePerguntaAtual + 1} de ${perguntas.length}`;
    const porcentagem = ((indicePerguntaAtual + 1) / perguntas.length) * 100;
    barraPreenchimento.style.width = `${porcentagem}%`;
    
    let dadosAtuais = perguntas[indicePerguntaAtual];
    perguntaTitulo.textContent = dadosAtuais.pergunta;
    
    // Criar os botões de opção limpos, sem erros sintáticos
    dadosAtuais.opcoes.forEach((opcao, index) => {
        const botaoOpcao = document.createElement('button');
        botaoOpcao.textContent = opcao;
        botaoOpcao.addEventListener('click', () => verificarResposta(index));
        opcoesContainer.appendChild(botaoOpcao);
    });
}

// Verificar Resposta
function verificarResposta(indiceSelecionado) {
    let dadosAtuais = perguntas[indicePerguntaAtual];
    
    // Desativar botões para prevenir múltiplos cliques rápidos
    const botoes = opcoesContainer.querySelectorAll('button');
    botoes.forEach(btn => btn.disabled = true);
    
    if (indiceSelecionado === dadosAtuais.correta) {
        pontuacao++;
        mensagemFeedback.textContent = "Correto! Excelente escolha sustentável. 🌿";
        mensagemFeedback.className = "acertou";
    } else {
        mensagemFeedback.textContent = `Incorreto. A resposta certa era: ${dadosAtuais.opcoes[dadosAtuais.correta]}`;
        mensagemFeedback.className = "errou";
    }
    
    // Delay de 1.5 segundos para leitura do feedback antes de avançar
    setTimeout(() => {
        indicePerguntaAtual++;
        if (indicePerguntaAtual < perguntas.length) {
            mostrarPergunta();
        } else {
            finalizarJogo();
        }
    }, 1500);
}

// Finalizar o Jogo e dar o resultado
function finalizarJogo() {
    telaJogo.classList.add('escondido');
    telaFim.classList.remove('escondido');
    
    pontuacaoFinal.textContent = `${pontuacao} / ${perguntas.length}`;
    
    if (pontuacao === perguntas.length) {
        mensagemDesempenho.textContent = "Incrível! Você tem total domínio sobre o equilíbrio e sustentabilidade no campo!";
    } else if (pontuacao >= 14) {
        mensagemDesempenho.textContent = "Muito bem! Suas escolhas protegem o meio ambiente e fortalecem o agro.";
    } else {
        mensagemDesempenho.textContent = "Bom esforço! Estude mais sobre as técnicas sustentáveis para melhorar sua pontuação.";
    }
}

// Ouvintes de eventos com verificação preventiva de segurança
if (btnComecar) btnComecar.addEventListener('click', iniciarJogo);
if (btnReiniciar) btnReiniciar.addEventListener('click', iniciarJogo);